------

Example Project Below README.md:

------

### Group Name: group74

### Members:
  - Nicholas Vogler - (nvogler) - worked with team members on all parts of the project, everyone contributed to each section
  - Kyle Kong - (kongzhij) - 
  - Xiaofeng Liu - (xiaofenl) - 

### Live Access:
  - [URL For Running Version](http://eecs485-23.eecs.umich.edu:2801/wludfv42t9/pa1/)

### Extra:
  - We called our `/pic` endpoint `/foto` (which you shouldn't but note any other special instructions here)
