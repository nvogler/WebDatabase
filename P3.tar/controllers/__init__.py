from album import *
from albums import *
from pic import *
from login import *
from user import *