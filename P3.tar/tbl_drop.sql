DROP TABLE Contain;
DROP TABLE AlbumAccess;
DROP TABLE Photo;
DROP TABLE Album;
DROP TABLE User;
DROP TRIGGER addphoto;
DROP TRIGGER deletephoto;